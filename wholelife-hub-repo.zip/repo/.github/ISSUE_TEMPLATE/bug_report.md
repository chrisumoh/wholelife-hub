---
name: Bug report
about: Something in WholeLife Hub isn't working
labels: bug
---

**Build:** (Settings › Data & about › Diagnostics, e.g. 8.1.8 (Dev Testing) · 2026-10-04)
**Device / browser / screen width:**
**Theme and Motion setting:** (Light / Dark / OLED · Bouncy / Reduced)
**Page:** (the address after #, e.g. #/settings/coach)

**Steps**
1.
2.
3.

**Expected:**
**Actual:**
**Screenshot or recording:**

**Related change-log entry (if known):** (e.g. 8.1.6 · Menu)

**Diagnostic log**
(paste the output of "Copy log for a bug report", or WLH.dump() in the console)
