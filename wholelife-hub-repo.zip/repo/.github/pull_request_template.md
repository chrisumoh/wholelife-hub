**Version:** (next build number, e.g. 8.1.9 — see docs/VERSIONING.md)
**Area:** (e.g. Header, Speed, Sys Architecture)

**What changed and why**

**How to test**

- [ ] Change-log entry added in `index.html` (`CHANGELOG` array) and `APP_VERSION.build` bumped
- [ ] `CHANGELOG.md` updated
- [ ] Tested at 375px and desktop, Light and Dark
- [ ] No errors in Diagnostics / `WLH.errors()`
- [ ] Any new Supabase table has RLS and a policy, with its migration in `supabase/migrations/`
